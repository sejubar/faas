#start SQL Server, start the script to create/setup the DB
 sh /db-init.sh & /opt/mssql/bin/sqlservr