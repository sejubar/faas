#wait for the SQL Server to come up
sleep 10s

echo "running set up script"
#run the setup script to create the DB and the schema in the DB
DB_PWD='mssql1Ipw'
DB_NAME='BikeStores'
/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P ${DB_PWD} -d master -Q "IF NOT EXISTS(SELECT 1 FROM sys.databases WHERE name='${DB_NAME}') CREATE DATABASE [${DB_NAME}]" &&
/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P ${DB_PWD} -d ${DB_NAME} -i BikeStores-sample-database-create-objects.sql &&
/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P ${DB_PWD} -d ${DB_NAME} -i BikeStoresSampleDatabase-loaddata.sql
